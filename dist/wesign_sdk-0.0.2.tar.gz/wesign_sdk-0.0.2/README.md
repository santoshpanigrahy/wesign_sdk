# Wesign SDK

[![PyPI - Version](https://img.shields.io/pypi/v/wesign-sdk.svg)](https://pypi.org/project/wesign-sdk)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/wesign-sdk.svg)](https://pypi.org/project/wesign-sdk)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install wesign-sdk
```

## License

`wesign-sdk` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
