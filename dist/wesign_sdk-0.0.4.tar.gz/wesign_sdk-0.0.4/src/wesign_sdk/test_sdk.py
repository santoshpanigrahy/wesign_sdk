# import src.wesign_sdk.sdk

# def test_sdk():
#     assert src.wesign_sdk.sdk.sdkFunction() == 1