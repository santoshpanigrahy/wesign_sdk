# SPDX-FileCopyrightText: 2024-present Mayur Patil <Mayur Patil>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.6"
