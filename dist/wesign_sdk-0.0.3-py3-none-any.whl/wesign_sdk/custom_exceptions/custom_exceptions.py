#custom_exception.py

class InvalidPathError(Exception):
    """Exception raised for invalid absolute paths."""
    def __init__(self, path, message="Provided path is not valid"):
        self.path = path
        self.message = message
        super().__init__(f"{message}: {path}")
        
class InvalidAPIKeyError(Exception):
    """Exception raised for an invalid API key."""
    def __init__(self, message="Invalid API key: The provided API key is not valid."):
        self.message = message
        super().__init__(self.message)


class FileUploadingError(Exception):
    """Exception raised for an uploading file."""
    def __init__(self, message="Error during uploading file."):
        self.message = message
        super().__init__(self.message)


class InvalidRecipientStructureError(Exception):
    """Exception raised when an action is required by the recipient"""
    def __init__(self, message="Invalid Recipient Structure : The provided recipient structure is not valid"):
        self.message = message
        super().__init__(self.message)
        
class InvalidHostError(Exception):
    """Exception raised for an invalid host"""
    def __init__(self, message="Invalid Recipient Structure : The provided recipient structure is not valid"):
        self.message = message
        super().__init__(self.message)
        
if __name__ == "__main__":
    # Code to execute if run as a script
    print("Running as a script")